
# About the Authors {-}

These credits are based on our [course contributors table guidelines](https://www.ottrproject.org/more_features.html#giving-credits-to-contributors).

&nbsp;
&nbsp;

|Credits|Names|
|-------|-----|
|**Pedagogy**||
|Lead Content Instructor(s)|[FirstName LastName]|
|Lecturer(s) (include chapter name/link in parentheses if only for specific chapters) - make new line if more than one chapter involved| Delivered the course in some way - video or audio|
|Content Author(s) (include chapter name/link in parentheses if only for specific chapters) - make new line if more than one chapter involved | If any other authors besides lead instructor|
|Content Contributor(s) (include section name/link in parentheses) - make new line if more than one section involved|  Wrote less than a chapter|
|Content Editor(s)/Reviewer(s) | Checked your content|
|Content Director(s) | Helped guide the content direction|
|Content Consultants (include chapter name/link in parentheses or word "General") - make new line if more than one chapter involved | Gave high level advice on content|
|Acknowledgments| Gave small assistance to content but not to the level of consulting |
|**Production**||
|Content Publisher(s)| Helped with publishing platform|
|Content Publishing Reviewer(s)| Reviewed overall content and aesthetics on publishing platform|
|**Technical**||
|Course Publishing Engineer(s)| Helped with the code for the technical aspects related to the specific course generation|
|Template Publishing Engineers|[Candace Savonen], [Carrie Wright], [Ava Hoffman]|
|Publishing Maintenance Engineer|[Candace Savonen]|
|Technical Publishing Stylists|[Carrie Wright], [Ava Hoffman], [Candace Savonen], [Katherine Cox]|
|Package Developers ([ottrpal]) | [Candace Savonen], [Ava Hoffman], [Howard Baek], [Kate Isaac], [Carrie Wright], [John Muschelli]|
|**Art and Design**||
|Illustrator(s)| Created graphics for the course|
|Figure Artist(s)| Created figures/plots for course|
|Videographer(s)| Filmed videos|
|Videography Editor(s)| Edited film|
|Audiographer(s)| Recorded audio|
|Audiography Editor(s)| Edited audio recordings|
|**Funding**||
|Funder(s)| Institution/individual who funded course including grant number|
|Funding Staff| Staff members who help with funding|

&nbsp;


```
## ─ Session info ───────────────────────────────────────────────────────────────
##  setting  value
##  version  R version 4.4.0 (2024-04-24)
##  os       Ubuntu 22.04.4 LTS
##  system   x86_64, linux-gnu
##  ui       X11
##  language (EN)
##  collate  en_US.UTF-8
##  ctype    en_US.UTF-8
##  tz       Etc/UTC
##  date     2026-03-30
##  pandoc   3.2 @ /usr/bin/ (via rmarkdown)
## 
## ─ Packages ───────────────────────────────────────────────────────────────────
##  package     * version date (UTC) lib source
##  bookdown      0.39    2024-04-15 [1] RSPM (R 4.4.0)
##  cachem        1.1.0   2024-05-16 [1] RSPM (R 4.4.0)
##  cli           3.6.2   2023-12-11 [1] RSPM (R 4.4.0)
##  devtools      2.4.5   2022-10-11 [1] RSPM (R 4.4.0)
##  digest        0.6.35  2024-03-11 [1] RSPM (R 4.4.0)
##  ellipsis      0.3.2   2021-04-29 [1] RSPM (R 4.4.0)
##  evaluate      0.24.0  2024-06-10 [1] RSPM (R 4.4.0)
##  fastmap       1.2.0   2024-05-15 [1] RSPM (R 4.4.0)
##  fs            1.6.4   2024-04-25 [1] RSPM (R 4.4.0)
##  glue          1.7.0   2024-01-09 [1] RSPM (R 4.4.0)
##  htmltools     0.5.8.1 2024-04-04 [1] RSPM (R 4.4.0)
##  htmlwidgets   1.6.4   2023-12-06 [1] RSPM (R 4.4.0)
##  httpuv        1.6.15  2024-03-26 [1] RSPM (R 4.4.0)
##  knitr         1.47    2024-05-29 [1] RSPM (R 4.4.0)
##  later         1.3.2   2023-12-06 [1] RSPM (R 4.4.0)
##  lifecycle     1.0.4   2023-11-07 [1] RSPM (R 4.4.0)
##  magrittr      2.0.3   2022-03-30 [1] RSPM (R 4.4.0)
##  memoise       2.0.1   2021-11-26 [1] RSPM (R 4.4.0)
##  mime          0.12    2021-09-28 [1] RSPM (R 4.4.0)
##  miniUI        0.1.1.1 2018-05-18 [1] RSPM (R 4.4.0)
##  pkgbuild      1.4.4   2024-03-17 [1] RSPM (R 4.4.0)
##  pkgload       1.3.4   2024-01-16 [1] RSPM (R 4.4.0)
##  profvis       0.3.8   2023-05-02 [1] RSPM (R 4.4.0)
##  promises      1.3.0   2024-04-05 [1] RSPM (R 4.4.0)
##  purrr         1.0.2   2023-08-10 [1] RSPM (R 4.4.0)
##  R6            2.5.1   2021-08-19 [1] RSPM (R 4.4.0)
##  Rcpp          1.0.12  2024-01-09 [1] RSPM (R 4.4.0)
##  remotes       2.5.0   2024-03-17 [1] RSPM (R 4.4.0)
##  rlang         1.1.4   2024-06-04 [1] RSPM (R 4.4.0)
##  rmarkdown     2.27    2024-05-17 [1] RSPM (R 4.4.0)
##  sessioninfo   1.2.2   2021-12-06 [1] RSPM (R 4.4.0)
##  shiny         1.8.1.1 2024-04-02 [1] RSPM (R 4.4.0)
##  stringi       1.8.4   2024-05-06 [1] RSPM (R 4.4.0)
##  stringr       1.5.1   2023-11-14 [1] RSPM (R 4.4.0)
##  urlchecker    1.0.1   2021-11-30 [1] RSPM (R 4.4.0)
##  usethis       2.2.3   2024-02-19 [1] RSPM (R 4.4.0)
##  vctrs         0.6.5   2023-12-01 [1] RSPM (R 4.4.0)
##  xfun          0.44    2024-05-15 [1] RSPM (R 4.4.0)
##  xtable        1.8-4   2019-04-21 [1] RSPM (R 4.4.0)
##  yaml          2.3.8   2023-12-11 [1] RSPM (R 4.4.0)
## 
##  [1] /usr/local/lib/R/site-library
##  [2] /usr/local/lib/R/library
## 
## ──────────────────────────────────────────────────────────────────────────────
```

<!-- Author information -->

[FirstName LastName]: link to personal website
[John Muschelli]: https://johnmuschelli.com/
[Candace Savonen]: https://www.cansavvy.com/
[Carrie Wright]: https://carriewright11.github.io/
[Ava Hoffman]: https://www.avahoffman.com/
[Howard Baek]: https://www.linkedin.com/in/howard-baik/
[Kate Isaac]: https://kweav.github.io/
[Katherine Cox]: https://katherinecox.github.io/

<!-- Links -->

[ottrpal]: https://github.com/ottrproject/ottrpal

<!-- Fill out this table using these instructions: https://www.ottrproject.org/more_features.html#giving-credits-to-contributors

For JHU courses, You will need to add Ira as a credit:

|Content Publisher|[Ira Gooding]|
...
[Ira Gooding]: https://publichealth.jhu.edu/faculty/4130/ira-gooding
-->
